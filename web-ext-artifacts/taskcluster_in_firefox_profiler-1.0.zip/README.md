# Taskcluster Graph

A visualization of taskcluster data.

https://gregtatum.github.io/taskcluster-tools

# Taskcluster WebExt

This project is a tool to visualize task graphs in the Firefox Profiler.

To install:

```
TODO
```

To run locally:

```
npm run start
```

To build:

```
npm run build
```
